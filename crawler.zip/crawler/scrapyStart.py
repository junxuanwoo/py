# -*- coding: utf-8 -*-

import os
import sys


#多进程,一个爬取,一个解析

def start():

    os.chdir(sys.path[0])

    #url提取

    #当url有出现'&'字符时,必须加\转义
    platforms = [
            ['www.glyd.cn', 'http://www.glyd.cn/invest/1733.html','glyd'],
            ['www.pp100.com','https://www.pp100.com/front/invest/investHome?currPage=2\&pageSize=10\&period=0\&searchType=0\&bidStatus=-1\&bidAmountLevel=\&apr=0', 'ybjr']
    ]

    for l in xrange(len(platforms)):
        os.system("scrapy crawl all -a allowed_domains={} -a start_urls={} -a rule_key={}".format(
            platforms[l][0], platforms[l][1], platforms[l][2]))


if __name__ == "__main__":
    start()