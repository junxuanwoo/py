# -*- coding: utf-8 -*-

#爬虫Spider模块

import re
import scrapy
from scrapy.selector import Selector
from scrapy.spiders import Spider
from crawler.items import ProductItem
from crawler.rulesConfig import productRule


class RowSpider(Spider):

    name = "all"

    def __init__(self, allowed_domains, start_urls, rule_key):
        self.allowed_domains = allowed_domains
        self.start_urls = [start_urls]
        self.rule_key = rule_key


    def start_requests(self):
        print 'start_request++++++++++++++++++++++++++++++++++++++++++++++++++++++'
        for start_url in self.start_urls:
            yield scrapy.Request(start_url, callback=self.prase_product, encoding='utf-8')

    def prase_product(self, response):
        print 'prase_product++++++++++++++++++++++++++++++++++++++++++++++++++++++'
        print productRule[self.rule_key]['platformid']
        sel = Selector(response)
        item = ProductItem()
        #print "还款期限——————————————————————————————————————", productRule[self.rule_key]['term']['ruleIndex']
        test = sel.xpath('//div[@class="fxndetail_wrap"]/table/tr/td[@class="fxndetail_wrap_td"]/text()'
                         ).extract()[productRule[self.rule_key]['term']['ruleIndex']]
        if productRule[self.rule_key]['term']['needre'] is True:
            item['term'] = re.search(productRule[self.rule_key]['term']['regex'], test)

        if item['term'] is not None:
            print '还款期限——————————————————————————————————————',item['term']


        return item
        # item['producttype'] = # 产品类型
        # item['productname'] = '格林e贷' + response.meta['productname'][0]# 产品名称
        # item['productid'] = response.meta['productid'][0] #产品ID
        # localInfo = sel.xpath('//div[@class="fxndetail_wrap"]/table/tr/td/text()').extract() # 获取5个信息
        # #print localInfo
        # item['amount'] = localInfo[0]# 标的总额(元)
        # item['balance'] = sel.xpath('//div[@class="fxndetail_wrap"]/div[@class="fxndetail_wrap_time"]/ul/li/dd[@class="org"]/text()')[1].extract().replace(r'元', '')#标的余额(元)
        # item['maxrate'] = localInfo[1].strip()# 最大收益率(%)
        # item['minrate'] = localInfo[1].strip()# 最小收益率(%)
        # item['startdate'] = response.meta['startdate'] # 产品发标时间
        # item['enddate'] = ''# 产品结标时间
        # term = self.regex.findall(localInfo[3]) # 还款期限
        # item['term'] = term[0]
        # item['termunit'] = localInfo[3][-1]# 还款期限单位
        # item['repaymentmethod'] = localInfo[2] # 还款方式
        #
        # values = (item['platformid'],item['producttype'],item['productname'].encode('utf-8'),item['productid'],item['amount'].encode('utf-8'),
        #           item['balance'].encode('utf-8'),item['maxrate'].encode('utf-8'),item['minrate'].encode('utf-8'),
        #           item['startdate'].encode('utf-8'),item['enddate'],item['term'],item['termunit'].encode('utf-8'),item['repaymentmethod'].encode('utf-8'))
        # items.append(item)
        # sql = 'insert into newbid_product_info_test1(platformid,producttype,productname,productid,amount,balance,maxrate,minrate,' \
        #       'startdate,enddate,term,termunit,repaymentmethod) values( %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)'
        # par = values
        # a = self.conn.find_product(item['platformid'], item['productid'])
        # if a == 0:
        #     self.conn.query(sql, par)
        # else:
        #     print '此数据数据库中已存在！'
        # return items

