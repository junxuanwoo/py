# -*- coding: utf-8 -*-

#规则文件

productRule = {
    #格林易贷
    'glyd' :
        {
            # 平台ID
            'platformid':'P00557***********',
            # 产品类型
            'producttype': {'xpath':'//div[@class="fxndetail_wrap"]/table/tr/td[@class="fxndetail_wrap_td"]/text()','ruleIndex':0,'needre':False, 'regex':r''},
            #产品名称
            'productname': {'ruleIndex':0,'needre':False, 'regex':r''},
            #产品ID
            'productid': {'ruleIndex':0,'needre':False, 'regex':r''},
            #标的总额
            'amount': {'ruleIndex':0,'needre':False, 'regex':r''},
            # 标的余额(元)
            'balance':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 最大收益率(%)
            'maxrate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 最小收益率(%)
            'minrate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 产品发标时间
            'startdate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 产品结标时间
            'enddate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 还款期限
            'term':  {'ruleIndex':1,'needre':True, 'regex':r'\d+'},
            # 还款期限单位
            'termunit':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 还款方式
            'repaymentmethod':  {'ruleIndex':0,'needre':False, 'regex':r''},
        },
    #壹佰金融
    'ybjr' :
        {
            # 平台ID
            'platformid':'P00558***********',
            # 产品类型
            'producttype': {'ruleIndex':0,'needre':False, 'regex':r''},
            #产品名称
            'productname': {'ruleIndex':0,'needre':False, 'regex':r''},
            #产品ID
            'productid': {'ruleIndex':0,'needre':False, 'regex':r''},
            #标的总额
            'amount': {'ruleIndex':0,'needre':False, 'regex':r''},
            # 标的余额(元)
            'balance':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 最大收益率(%)
            'maxrate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 最小收益率(%)
            'minrate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 产品发标时间
            'startdate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 产品结标时间
            'enddate':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 还款期限
            'term':  {'ruleIndex':1,'needre':True, 'regex':r'\d+'},
            # 还款期限单位
            'termunit':  {'ruleIndex':0,'needre':False, 'regex':r''},
            # 还款方式
            'repaymentmethod':  {'ruleIndex':0,'needre':False, 'regex':r''},
        }
};

